Python Libraries required:
-flask
-flask_sqlalchemy
-flask_bcrypt
-flask_login
-flask_wtf
-wtforms

To run:
bash run.sh
